<?php require __DIR__ . '/parts/connect_db.php' ?>
<?php
$pageName = "comment";
$title = "評論管理";



//列表控制
$perpage = 10; //每一頁的最高筆數
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
if ($page < 1) {
    header('location: ?page=1');
    exit;
}
$t_sql = "SELECT COUNT(1) FROM rating";
//取得總比數
$totalRows = $pdo->query($t_sql)->fetch(PDO::FETCH_NUM)[0];
//總頁數
$totalPages = ceil($totalRows / $perpage);

$rows = [];
$rows_sql = "SELECT * FROM `rating` WHERE 1";
$sql = sprintf("SELECT * FROM `rating` ORDER BY `sid` ASC LIMIT %s, %s", ($page - 1) * $perpage, $perpage);
$rows = $pdo->query($sql)->fetchAll();

$member_rows = [];
$member_rows_sql = "SELECT `sid`, `name` FROM `member` WHERE 1";
$member_rows = $pdo->query($member_rows_sql)->fetchAll();

$trail_rows = [];
$trail_rows_sql = "SELECT `sid`, `trail_name` FROM `trails` WHERE 1";
$trail_rows = $pdo->query($trail_rows_sql)->fetchAll();


if ($totalRows > 0) {
    if ($page > $totalPages) {
        header('location: ?page=' . $totalPages);
        exit;
    }
}

$sid = isset($_GET['sid']) ? intval($_GET['sid']) : 0;
if (empty($sid)) {
    // header('Location: comment.php');

}

//編輯評論用 fetch
$sql_edit = "SELECT * FROM `rating` WHERE sid=$sid";
$r = $pdo->query($sql_edit)->fetch();
if (empty($r)) {
    header('Location: comment.php');
    exit;
}
?>
<?php require __DIR__ . '/parts/html-head.php' ?>
<?php require __DIR__ . '/parts/navbar.php' ?>
<div class="container">
    <div class="row">
        <h2>comment</h2>
        <!-- 篩選功能欄位 -->

        <!-- pagination -->
        <nav aria-label="Page navigation example">
            <ul class="pagination">
                <li class="page-item <?= $page == 1 ? 'disabled' : '' ?>">
                    <a class="page-link" href="?page=1">第一頁</a>
                </li>
                <?php for ($i = $page - 5; $i <= $page + 5; $i++) :
                    if ($i >= 1 and $i <= $totalPages) :
                ?>
                        <li class="page-item <?= $page == $i ? 'active' : '' ?>">
                            <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                        </li>
                <?php
                    endif;
                endfor;
                ?>
                <li class="page-item <?= $page == $totalPages ? 'disabled' : '' ?>">
                    <a class="page-link" href="?page=<?= $totalPages ?>">最後一頁</a>
                </li>
            </ul>
        </nav>

        <!-- 跳出修改視窗 -->
        <div class="popup_card" id="popup_card">
            <div class="popup_flex d-flex pt-3">
                <i class="fa-regular fa-circle-xmark" onclick="closePop()" id="close_pop"></i>
                <div class="comment_area me-2">
                    <h6 class="text-center">顧客評價</h6>
                    <div class="comment_box">
                        <p class=" pt-3 pe-2" id="comment_show">
                            <?= $rows['sid']['comment'] ?>
                        </p>
                    </div>
                </div>
                <form name="edit_form" method="POST" class="reply_area d-flex flex-column" onsubmit="edit_reply(event)">
                    <label for="reply_show" class="form-label text-center">回覆顧客</label>
                    <textarea name="reply_show" class="form-control mt-3" id="reply_show" rows="10" cols="50"><?= $rows['reply'] ?></textarea>
                    <button class="btn btn-primary mt-3 mb-3" type="submit">送出</button>
                </form>

            </div>
        </div>

        <!-- 表格 -->
        <table class="table table-striped table-hover align-middle">
            <thead class="">
                <tr>
                    <th>#</th>
                    <th class="th_member">評論人</th>
                    <th class="th_rate">評價</th>
                    <th class="th_trails">參加行程</th>
                    <th class="th_date">日期</th>
                    <th class="th_comment">內容</th>
                    <th class="th_reply">回覆</th>
                    <th>動作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rows as $r) : ?>
                    <tr class="tr_row">
                        <td><?= $r['sid'] ?></td>
                        <td>
                            <?php foreach ($member_rows as $m_r) : ?>
                                <?php
                                if ($m_r['sid'] === $r['member_sid']) {
                                    echo $m_r['name'];
                                }
                                ?>
                            <?php endforeach ?>
                        </td>

                        <td class="td_score">
                            <?php
                            if ($r['score'] == 5) {
                                echo '<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>';
                            } else if ($r['score'] == 4) {
                                echo '<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-regular fa-star"></i>';
                            } else if ($r['score'] == 3) {
                                echo '<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-regular fa-star"></i><i class="fa-regular fa-star"></i>';
                            } else if ($r['score'] == 2) {
                                echo '<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-regular fa-star"></i><i class="fa-regular fa-star"></i><i class="fa-regular fa-star"></i>';
                            } else if ($r['score'] == 1) {
                                echo '<i class="fa-solid fa-star"></i><i class="fa-regular fa-star"></i><i class="fa-regular fa-star"></i><i class="fa-regular fa-star"></i><i class="fa-regular fa-star"></i>';
                            } else {
                                echo '<i class="fa-regular fa-star"></i><i class="fa-regular fa-star"></i><i class="fa-regular fa-star"></i><i class="fa-regular fa-star"></i><i class="fa-regular fa-star"></i>';
                            }
                            ?>
                        </td>

                        <td>
                            <?php foreach ($trail_rows as $t_r) : ?>
                                <?php
                                if ($t_r['sid'] === $r['trails_sid']) {
                                    echo $t_r['trail_name'];
                                }
                                ?>
                            <?php endforeach ?>
                        </td>
                        <td><?= $r['rate_date'] ?></td>
                        <td class="td_comment"><?= $r['comment'] ?></td>
                        <td class="td_comment">
                            <?php
                            if ($r['reply'] === '' || $r['reply'] == NULL) {
                                $reply_btn_text = '回覆';
                                $reply_btn = 'primary';
                                echo '未回覆';
                            } else {
                                $reply_btn_text = '修改';
                                $reply_btn = 'outline-success';
                                echo $r['reply'];
                            }
                            ?>
                        </td>
                        <td>
                            <a class="btn btn-<?= $reply_btn ?>" onclick="openPop([<?= $r['sid'] ?>,'<?= $r['comment'] ?>','<?= $r['reply'] ?>'])"> <?= $reply_btn_text ?></a>
                            <a class="btn btn-warning mt-1" onclick="delItem(<?= $r['sid'] ?>)">
                                刪除
                            </a>
                        </td>
                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>

        <!-- pagination -->
        <nav aria-label="Page navigation example">
            <ul class="pagination">
                <li class="page-item <?= $page == 1 ? 'disabled' : '' ?>">
                    <a class="page-link" href="?page=1">第一頁</a>
                </li>
                <?php for ($i = $page - 5; $i <= $page + 5; $i++) :
                    if ($i >= 1 and $i <= $totalPages) :
                ?>
                        <li class="page-item <?= $page == $i ? 'active' : '' ?>">
                            <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                        </li>
                <?php
                    endif;
                endfor;
                ?>
                <li class="page-item <?= $page == $totalPages ? 'disabled' : '' ?>">
                    <a class="page-link" href="?page=<?= $totalPages ?>">最後一頁</a>
                </li>
            </ul>
        </nav>

    </div>
</div>

<?php require __DIR__ . '/parts/scripts.php' ?>
<script>
    //刪除功能
    function delItem(sid) {
        if (confirm(`確定要刪除編號${sid}的評論？`)) {
            // event.currentTarget.closest('tr').remove();
            location.href = 'comment-delete.php?sid=' + sid;
            console.log('ok');
        } else {
            console.log('canceled');
        }
    }

    //打開popup視窗
    const p = document.querySelector('.popup_card');
    const p_comment = document.querySelector('#comment_show');
    const p_reply = document.querySelector('#reply_show');
    const close_btn = document.querySelector('#close_pop');
    const ary = [];


    function openPop(ary) {
        // location.href = `?sid=${sid}`;
        event.preventDefault();
        if (!p.classList.contains('popup_card_open')) {
            p.classList.remove('popup_card');
            p.classList.add('popup_card_open');

            function save_data(ary) {
                const reply_obj = {
                    obj_sid: ary[0],
                    obj_reply: ary[2],
                    obj_comment: ary[1],
                }
                // console.log(reply_obj);
                // localStorage.setItem('reply_data', JSON.stringify(reply_obj));
                p_reply.innerHTML = ary[2];
                p_comment.innerHTML = ary[1];
            }
            save_data(ary);
            // console.log(document.edit_form.reply_show);
        }
    }
    //修改回覆

    const edit_reply = function(event) {
        event.preventDefault();
        const fd = new FormData(document.edit_form);
        fetch('comment-edit-api.php', {
            method: 'POST',
            body: fd,
        }).then(response => response.json()).then(obj => {
            console.log(obj);
        })
    }

    function closePop() {
        p.classList.remove('popup_card_open');
        p.classList.add('popup_card');
    }
</script>
<?php require __DIR__ . '/parts/html-foot.php' ?>