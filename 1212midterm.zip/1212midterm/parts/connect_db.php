<?php


//自己電腦路徑的pdo
define('PROJ_ROOT', '/1212midterm');

$db_host = 'localhost';
$db_user = 'root';
$db_pass = '0921218220';
$db_name = 'peh-suann-lai';

//peh-suann教室的pdo
// define('PROJ_ROOT', '/1212midterm');

// $db_host = '192.168.21.84'; //我的教室電腦的IP
// $db_user = 'mountain';
// $db_pass = 'mountaindude55';
// $db_name = 'mountain';

$dsn = "mysql:host={$db_host};dbname={$db_name};charset=utf8";

$pdo_options = [
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
];

$pdo = new PDO($dsn, $db_user, $db_pass, $pdo_options);


if (!isset($_SESSION)) {
    session_start();
}
