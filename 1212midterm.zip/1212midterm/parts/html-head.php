<!DOCTYPE JSON>
<html lang="zh">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title><?= $title . " peh-suann" ?></title>
    <style>
        /* CSS */
        body {
            margin: 0;
            padding: 0;
        }

        .tr_row {
            overflow: hidden;
            text-overflow: ellipsis;
            height: 100px;
        }

        .td_score {
            table-layout: fixed;
            width: 150px;
        }

        .td_comment {
            overflow: hidden;
            /* white-space: nowrap; */
            /* text-overflow: ellipsis; */
        }


        .th_comment {
            table-layout: fixed;
            width: 350px;
        }

        .th_trails {
            table-layout: fixed;
            width: 180px;
        }

        .th_date {
            table-layout: fixed;
            width: 100px;
        }

        .th_rate {
            table-layout: fixed;
            width: 100px;
        }

        .th_reply {
            table-layout: fixed;
            width: 150px;
        }

        .th_member {
            table-layout: fixed;
            width: 100px;
        }

        .pagination {
            position: relative;
        }

        .popup_card {
            z-index: 1;
            width: 50%;
            height: 500px;
            background-color: #F8F9FA;
            border-radius: 5px;
            box-shadow: rgba(0, 0, 0, 0.4) 0px 4px 12px;
            position: absolute;
            left: 45%;
            top: 30vh;
            transform: scale(0.1);
            visibility: hidden;
        }

        .popup_card_open {
            z-index: 1;
            width: 50%;
            /* height: 500px; */
            background-color: #F8F9FA;
            border-radius: 5px;
            box-shadow: rgba(0, 0, 0, 0.4) 0px 4px 12px;
            position: absolute;
            left: 60vh;
            top: 30vh;
            /* transform: scale(0.1); */
            /* visibility: hidden; */
        }

        .comment_area {
            width: 50%;
        }

        .reply_area {
            width: 50%;
        }

        .comment_box {
            height: 200px;
            width: 100%;
            /* background-color: #fff; */
            /* border: 1px solid #eeeeee; */
        }

        .reply_box {
            height: 200px;
            width: 100%;
            background-color: #fff;
            border: 1px solid #eeeeee;
        }
    </style>
</head>

<body>
    <div class="container-fluid d-flex p-0">