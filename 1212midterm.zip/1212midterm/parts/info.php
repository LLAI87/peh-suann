<?php

PHPinfo();