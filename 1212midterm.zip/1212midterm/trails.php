<?php require __DIR__ . '/parts/connect_db.php' ?>
<?php
$pageName = "trails";
$title = "trails";
?>
<?php require __DIR__ . '/parts/html-head.php' ?>
<?php require __DIR__ . '/parts/navbar.php' ?>
<h6>trails</h6>
<?php require __DIR__ . '/parts/scripts.php' ?>
<?php require __DIR__ . '/parts/html-foot.php' ?>